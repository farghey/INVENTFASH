<?php include("templetes/header.php");?>
<br/>
<div class="p-5 mb-4 bg-light rounded-3">
  <div class="container-fluid py-5">
    <h1 class="display-5 fw-bold">Bienvenid@s al administrador </h1>
    <p class="col-md-8 fs-4">En este administrador usted podra controlar todo el contenido del sitio web.</p>
  </div>
  </div>
<?php include("templetes/footer.php");?>





  